# Air Quality Index (AQI) Analysis

**Tools:** Python · Pandas · Matplotlib · Seaborn

End-to-end exploratory data analysis of air quality across six major Indian cities
(Delhi, Patna, Kolkata, Mumbai, Bangalore, Chennai) over 2023 — from raw, messy
sensor data to a cleaned dataset, computed AQI scores, and actionable insights.

## What this project does

- **Performed end-to-end EDA** on daily AQI datasets covering 6 cities and 4 regions
- **Cleaned and transformed environmental data**: fixed inconsistent city labels,
  removed duplicate records, corrected physically impossible readings, and imputed
  missing pollutant values using per-city medians
- **Computed AQI** from raw pollutant concentrations (PM2.5, PM10) using the standard
  CPCB sub-index methodology
- **Built visualizations** comparing pollution trends across regions and seasons
- **Generated actionable insights** for environmental monitoring and policy

## Project structure

```
aqi-index-analysis/
├── data/
│   ├── air_quality_raw.csv        # raw dataset (with intentional real-world messiness)
│   └── air_quality_cleaned.csv    # cleaned dataset with computed AQI
├── notebooks/
│   └── AQI_Analysis.ipynb         # full notebook with narrative + outputs
├── src/
│   └── aqi_analysis.py            # standalone script version of the pipeline
├── images/                        # exported charts
├── requirements.txt
└── README.md
```

## Key visualizations

**Average AQI by city**

![Average AQI by City](images/avg_aqi_by_city.png)

**Monthly AQI trend (seasonal pattern)**

![Monthly AQI Trend](images/monthly_aqi_trend.png)

**AQI distribution by region**

![AQI Distribution by Region](images/aqi_distribution_by_region.png)

**Pollutant correlation heatmap**

![Pollutant Correlation Heatmap](images/pollutant_correlation_heatmap.png)

## Key insights

- **Delhi and Patna** recorded the highest average AQI in 2023, spending most days in
  the "Poor" to "Severe" range, driven by elevated PM2.5/PM10.
- **Winter months (Nov–Feb)** show a sharp AQI spike across northern/eastern cities,
  consistent with temperature inversion and crop-residue burning season.
- **Monsoon months (Jun–Sep)** show the cleanest air across every city — rainfall
  washes out particulate matter.
- **Southern cities (Bangalore, Chennai)** maintained the best air quality year-round.
- **PM2.5 and PM10 are highly correlated (~0.9+)**, confirming particulate matter as
  the dominant shared driver of AQI.

## How to run

```bash
git clone https://github.com/<your-username>/aqi-index-analysis.git
cd aqi-index-analysis
pip install -r requirements.txt

# Option 1: run the script
python src/aqi_analysis.py

# Option 2: explore the notebook
jupyter notebook notebooks/AQI_Analysis.ipynb
```

## Data note

This project uses a synthetically generated dataset modeled on realistic pollutant
concentration ranges and seasonal patterns for each city, with intentionally injected
data quality issues (missing values, duplicates, inconsistent labels, outliers) to
demonstrate a genuine data-cleaning workflow. Swap in a real AQI dataset (e.g. from
CPCB or Kaggle) by matching the same column schema (`Date, City, Region, PM2.5, PM10,
NO2, SO2, CO, O3`) to run this pipeline on live data.

## License

MIT
