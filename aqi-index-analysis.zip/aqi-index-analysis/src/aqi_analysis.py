"""
Air Quality Index (AQI) Analysis
---------------------------------
End-to-end EDA pipeline: load -> clean -> compute AQI -> visualize -> insights.

Run:
    python src/aqi_analysis.py

Outputs cleaned CSV to data/air_quality_cleaned.csv and charts to images/.
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme(style="whitegrid", palette="deep")
plt.rcParams["figure.dpi"] = 110

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
IMG_DIR = os.path.join(BASE_DIR, "images")
POLLUTANT_COLS = ["PM2.5", "PM10", "NO2", "SO2", "CO", "O3"]


def load_data(path):
    return pd.read_csv(path)


def clean_data(df):
    df = df.copy()

    # Standardize city names (fix whitespace/casing inconsistencies)
    df["City"] = df["City"].str.strip().str.title()

    # Drop exact duplicate rows
    df = df.drop_duplicates()

    # Fix physically impossible negative pollutant readings
    for col in POLLUTANT_COLS:
        df.loc[df[col] < 0, col] = np.nan

    # Impute missing values using per-city median (robust, preserves city profile)
    for col in POLLUTANT_COLS:
        df[col] = df.groupby("City")[col].transform(lambda x: x.fillna(x.median()))

    # Parse dates & add time features
    df["Date"] = pd.to_datetime(df["Date"])
    df["Month"] = df["Date"].dt.month

    def get_season(month):
        if month in [11, 12, 1, 2]:
            return "Winter"
        elif month in [6, 7, 8, 9]:
            return "Monsoon"
        return "Summer/Spring"

    df["Season"] = df["Month"].apply(get_season)
    return df


def pm25_subindex(x):
    if x <= 30: return x * (50 / 30)
    elif x <= 60: return 50 + (x - 30) * (50 / 30)
    elif x <= 90: return 100 + (x - 60) * (100 / 30)
    elif x <= 120: return 200 + (x - 90) * (100 / 30)
    elif x <= 250: return 300 + (x - 120) * (100 / 130)
    return 400 + (x - 250) * (100 / 130)


def pm10_subindex(x):
    if x <= 100: return x
    elif x <= 250: return 100 + (x - 100) * (100 / 150)
    elif x <= 350: return 200 + (x - 250)
    elif x <= 430: return 300 + (x - 350) * (100 / 80)
    return 400 + (x - 430) * (100 / 80)


def aqi_category(aqi):
    if aqi <= 50: return "Good"
    elif aqi <= 100: return "Satisfactory"
    elif aqi <= 200: return "Moderate"
    elif aqi <= 300: return "Poor"
    elif aqi <= 400: return "Very Poor"
    return "Severe"


def compute_aqi(df):
    df = df.copy()
    df["PM25_SubIndex"] = df["PM2.5"].apply(pm25_subindex)
    df["PM10_SubIndex"] = df["PM10"].apply(pm10_subindex)
    df["AQI"] = df[["PM25_SubIndex", "PM10_SubIndex"]].max(axis=1).round(0)
    df["AQI_Category"] = df["AQI"].apply(aqi_category)
    return df


def make_visualizations(df):
    os.makedirs(IMG_DIR, exist_ok=True)

    # 1. Average AQI by city
    plt.figure(figsize=(9, 5))
    city_avg = df.groupby("City")["AQI"].mean().sort_values(ascending=False)
    sns.barplot(x=city_avg.values, y=city_avg.index, hue=city_avg.index,
                palette="rocket", legend=False)
    plt.xlabel("Average AQI (2023)")
    plt.title("Average Air Quality Index by City")
    for i, v in enumerate(city_avg.values):
        plt.text(v + 2, i, f"{v:.0f}", va="center")
    plt.tight_layout()
    plt.savefig(os.path.join(IMG_DIR, "avg_aqi_by_city.png"), bbox_inches="tight")
    plt.close()

    # 2. Monthly trend by city
    monthly = df.groupby(["Month", "City"])["AQI"].mean().reset_index()
    plt.figure(figsize=(11, 6))
    sns.lineplot(data=monthly, x="Month", y="AQI", hue="City", marker="o", linewidth=2)
    plt.xticks(range(1, 13), ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"])
    plt.title("Monthly AQI Trend by City (2023)")
    plt.legend(bbox_to_anchor=(1.02, 1), loc="upper left")
    plt.tight_layout()
    plt.savefig(os.path.join(IMG_DIR, "monthly_aqi_trend.png"), bbox_inches="tight")
    plt.close()

    # 3. AQI distribution by region
    plt.figure(figsize=(9, 5.5))
    region_order = df.groupby("Region")["AQI"].median().sort_values(ascending=False).index
    sns.boxplot(data=df, x="Region", y="AQI", order=region_order, hue="Region",
                palette="coolwarm", legend=False)
    plt.title("AQI Distribution by Region")
    plt.tight_layout()
    plt.savefig(os.path.join(IMG_DIR, "aqi_distribution_by_region.png"), bbox_inches="tight")
    plt.close()

    # 4. Pollutant correlation heatmap
    plt.figure(figsize=(7, 6))
    corr = df[POLLUTANT_COLS + ["AQI"]].corr()
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="viridis", square=True, linewidths=0.5)
    plt.title("Correlation Between Pollutants and AQI")
    plt.tight_layout()
    plt.savefig(os.path.join(IMG_DIR, "pollutant_correlation_heatmap.png"), bbox_inches="tight")
    plt.close()

    print(f"Saved 4 charts to {IMG_DIR}")


def main():
    raw_path = os.path.join(DATA_DIR, "air_quality_raw.csv")
    df = load_data(raw_path)
    print(f"Loaded raw data: {df.shape}")

    df_clean = clean_data(df)
    df_clean = compute_aqi(df_clean)
    print(f"Cleaned data: {df_clean.shape}")

    out_path = os.path.join(DATA_DIR, "air_quality_cleaned.csv")
    df_clean.to_csv(out_path, index=False)
    print(f"Saved cleaned data to {out_path}")

    make_visualizations(df_clean)

    print("\n--- Summary ---")
    print(df_clean.groupby("City")["AQI"].mean().sort_values(ascending=False).round(1))


if __name__ == "__main__":
    main()
