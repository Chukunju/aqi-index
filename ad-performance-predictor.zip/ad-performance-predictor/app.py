"""
Gradio app: Social Media Advertisement Performance Predictor

Deploy on Hugging Face Spaces by pushing this repo with:
    sdk: gradio
    app_file: app.py
in the Space's README front-matter (see the "Deploying to Hugging Face Spaces"
section of the project README).

On first load, this loads the trained XGBoost model + embedder + sentiment analyzer.
If the embedder/sentiment models were trained using the TF-IDF+SVD / lexicon fallback
(e.g. because they were trained offline), the app will use that same fallback for
consistency between training and inference. Retrain with internet access to use real
BERT embeddings end-to-end.
"""

import os
import sys
import pickle
import numpy as np
import pandas as pd
import gradio as gr

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "models")
sys.path.append(os.path.join(BASE_DIR, "src"))  # needed to unpickle TextEmbedder / SentimentAnalyzer

with open(os.path.join(MODEL_DIR, "xgb_model.pkl"), "rb") as f:
    model = pickle.load(f)
with open(os.path.join(MODEL_DIR, "feature_columns.pkl"), "rb") as f:
    feature_columns = pickle.load(f)
with open(os.path.join(MODEL_DIR, "embedder.pkl"), "rb") as f:
    embedder = pickle.load(f)
with open(os.path.join(MODEL_DIR, "sentiment_analyzer.pkl"), "rb") as f:
    sentiment_analyzer = pickle.load(f)

CATEGORIES = ["Fashion", "Beauty", "Fitness", "Food & Beverage", "Home & Living",
              "Tech & Gadgets", "Outdoor & Travel"]
IMAGE_TYPES = ["Single Image", "Carousel", "Reel/Video", "Story"]
DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def build_single_feature_row(caption, category, image_type, day_of_week, hashtag_count,
                              followers, post_hour):
    embedding = embedder.transform([caption])
    sentiment = sentiment_analyzer.score([caption])[0]

    emb_df = pd.DataFrame(embedding, columns=[f"emb_{i}" for i in range(embedding.shape[1])])
    emb_df["sentiment_score"] = sentiment

    caption_length = len(caption)
    is_weekend = int(day_of_week in ["Sat", "Sun"])
    log_followers = np.log1p(followers)

    meta = pd.DataFrame([{
        "hashtag_count": hashtag_count,
        "post_hour": post_hour,
        "caption_length": caption_length,
        "is_weekend": is_weekend,
        "log_followers": log_followers,
    }])

    cat_dummy = pd.DataFrame([{f"category_{c}": int(c == category) for c in CATEGORIES[1:]}])
    img_dummy = pd.DataFrame([{f"image_type_{t}": int(t == image_type) for t in IMAGE_TYPES[1:]}])
    day_dummy = pd.DataFrame([{f"day_of_week_{d}": int(d == day_of_week) for d in DAYS[1:]}])

    row = pd.concat([meta, cat_dummy, img_dummy, day_dummy, emb_df], axis=1)
    row = row.reindex(columns=feature_columns, fill_value=0)
    return row, sentiment


def predict(caption, category, image_type, day_of_week, hashtag_count, followers, post_hour):
    if not caption or not caption.strip():
        return "Please enter a caption.", "", ""

    row, sentiment = build_single_feature_row(
        caption, category, image_type, day_of_week, int(hashtag_count),
        int(followers), int(post_hour)
    )
    proba = model.predict_proba(row)[0]
    pred_class = int(np.argmax(proba))
    label = "High Engagement" if pred_class == 1 else "Low Engagement"
    confidence = proba[pred_class]

    sentiment_label = "Positive" if sentiment > 0.15 else ("Negative" if sentiment < -0.15 else "Neutral")

    result = f"### Prediction: {'🟢' if label == 'High Engagement' else '🔴'} {label}\n"
    result += f"**Confidence:** {confidence:.1%}\n\n"
    result += f"**Detected caption sentiment:** {sentiment_label} (score: {sentiment:+.2f})"

    backend_note = (
        f"Embedding backend: {'BERT (sentence-transformers)' if embedder.using_bert else 'TF-IDF+SVD fallback'} | "
        f"Sentiment backend: {'transformer' if sentiment_analyzer.using_transformer else 'lexicon fallback'}"
    )

    return result, f"{proba[1]:.1%} High / {proba[0]:.1%} Low", backend_note


with gr.Blocks(title="Ad Performance Predictor") as demo:
    gr.Markdown("""
    # 📊 Social Media Advertisement Performance Predictor
    Predict whether an Instagram ad post will achieve **High** or **Low** engagement,
    based on the caption text (via BERT embeddings + sentiment analysis) and post metadata.

    *Model: XGBoost classifier, ~83% test accuracy. Trained on 12,500+ synthetic Instagram ad posts.*
    """)

    with gr.Row():
        with gr.Column():
            caption = gr.Textbox(
                label="Ad Caption",
                placeholder="e.g. Absolutely love this new collection! Shop now before it's gone. #newlaunch #musthave",
                lines=3,
            )
            category = gr.Dropdown(CATEGORIES, value="Fashion", label="Category")
            image_type = gr.Dropdown(IMAGE_TYPES, value="Reel/Video", label="Post Format")
            day_of_week = gr.Dropdown(DAYS, value="Fri", label="Day of Week")
            hashtag_count = gr.Slider(0, 15, value=5, step=1, label="Number of Hashtags")
            followers = gr.Number(value=25000, label="Follower Count")
            post_hour = gr.Slider(0, 23, value=18, step=1, label="Post Hour (24h)")
            btn = gr.Button("Predict Engagement", variant="primary")

        with gr.Column():
            output_main = gr.Markdown(label="Result")
            output_proba = gr.Textbox(label="Class Probabilities")
            output_backend = gr.Textbox(label="Backend Info", interactive=False)

    btn.click(
        predict,
        inputs=[caption, category, image_type, day_of_week, hashtag_count, followers, post_hour],
        outputs=[output_main, output_proba, output_backend],
    )

    gr.Examples(
        examples=[
            ["Absolutely love this new collection, best purchase ever! Shop now before it's gone. #newlaunch #musthave #instagood",
             "Fashion", "Reel/Video", "Fri", 4, 45000, 18],
            ["Introducing the latest gadget, now available in stores.",
             "Tech & Gadgets", "Single Image", "Tue", 0, 8000, 10],
            ["Disappointed with this purchase, wouldn't recommend, poor quality overall.",
             "Beauty", "Story", "Mon", 2, 12000, 9],
        ],
        inputs=[caption, category, image_type, day_of_week, hashtag_count, followers, post_hour],
    )

if __name__ == "__main__":
    demo.launch()
