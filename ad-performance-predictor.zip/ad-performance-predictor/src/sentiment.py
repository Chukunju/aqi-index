"""
Sentiment analysis utilities.

Primary path: a pretrained transformer sentiment pipeline
(distilbert-base-uncased-finetuned-sst-2-english) via Hugging Face `transformers`.

Fallback path: a lightweight lexicon-based sentiment scorer, used automatically
when the transformer model can't be downloaded (see embeddings.py for the same
graceful-degradation pattern).
"""

import re
import warnings

_POSITIVE_WORDS = {
    "love", "amazing", "great", "best", "happy", "recommend", "exceeded",
    "worth", "perfect", "incredible", "stunning", "obsessed", "changer",
    "quality", "five", "stars", "changing"
}
_NEGATIVE_WORDS = {
    "disappointed", "not", "waste", "poor", "wouldn't", "expected", "let",
    "down", "overpriced", "broke", "terrible", "regret", "cheaply", "doesn't"
}


def _try_load_transformer_sentiment():
    try:
        from transformers import pipeline
        clf = pipeline("sentiment-analysis", model="distilbert-base-uncased-finetuned-sst-2-english")
        return clf
    except Exception as e:
        warnings.warn(
            f"Could not load transformer sentiment model ({type(e).__name__}: {e}). "
            "Falling back to lexicon-based sentiment scoring."
        )
        return None


class SentimentAnalyzer:
    def __init__(self):
        self.pipeline = _try_load_transformer_sentiment()
        self.using_transformer = self.pipeline is not None

    def score(self, texts):
        """Returns a list of floats in [-1, 1], positive = more positive sentiment."""
        if self.using_transformer:
            results = self.pipeline(list(texts), truncation=True)
            return [r["score"] if r["label"] == "POSITIVE" else -r["score"] for r in results]

        scores = []
        for text in texts:
            words = re.findall(r"[a-z']+", text.lower())
            pos = sum(1 for w in words if w in _POSITIVE_WORDS)
            neg = sum(1 for w in words if w in _NEGATIVE_WORDS)
            total = pos + neg
            scores.append((pos - neg) / total if total else 0.0)
        return scores
