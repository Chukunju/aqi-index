"""
Text embedding utilities.

Primary path: sentence-transformers ('all-MiniLM-L6-v2', a distilled BERT model) —
used whenever the model can be downloaded (i.e. any environment with internet access,
including Hugging Face Spaces).

Fallback path: if the transformer model can't be loaded (no internet access, package
not installed, etc.), automatically degrades to a TF-IDF + Truncated SVD embedding of
the same dimensionality, so the pipeline still runs end-to-end. This mirrors a common
production pattern: services should degrade gracefully rather than hard-fail when an
external model registry is unreachable.
"""

import warnings
import numpy as np

EMBEDDING_DIM = 384  # matches all-MiniLM-L6-v2 output dimension


def _try_load_bert_encoder():
    try:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer("all-MiniLM-L6-v2")
        return model
    except Exception as e:
        warnings.warn(
            f"Could not load sentence-transformers BERT model ({type(e).__name__}: {e}). "
            "Falling back to TF-IDF + SVD embeddings. This is expected in offline/sandboxed "
            "environments; on a machine with internet access (e.g. Hugging Face Spaces), "
            "real BERT embeddings will be used automatically."
        )
        return None


class TextEmbedder:
    """
    Unified interface: .fit_transform(texts) during training, .transform(texts) at
    inference time. Uses BERT sentence embeddings when available, otherwise TF-IDF+SVD.
    """

    def __init__(self, dim=EMBEDDING_DIM):
        self.dim = dim
        self.bert_model = _try_load_bert_encoder()
        self.using_bert = self.bert_model is not None
        self._vectorizer = None
        self._svd = None

    def fit_transform(self, texts):
        texts = list(texts)
        if self.using_bert:
            return self.bert_model.encode(texts, show_progress_bar=False)

        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.decomposition import TruncatedSVD

        self._vectorizer = TfidfVectorizer(max_features=5000, stop_words="english", ngram_range=(1, 2))
        tfidf = self._vectorizer.fit_transform(texts)

        n_components = min(self.dim, tfidf.shape[1] - 1, tfidf.shape[0] - 1)
        self._svd = TruncatedSVD(n_components=n_components, random_state=42)
        reduced = self._svd.fit_transform(tfidf)

        if reduced.shape[1] < self.dim:
            pad = np.zeros((reduced.shape[0], self.dim - reduced.shape[1]))
            reduced = np.hstack([reduced, pad])
        return reduced

    def transform(self, texts):
        texts = list(texts)
        if self.using_bert:
            return self.bert_model.encode(texts, show_progress_bar=False)

        if self._vectorizer is None or self._svd is None:
            raise RuntimeError("Call fit_transform before transform when using the fallback embedder.")

        tfidf = self._vectorizer.transform(texts)
        reduced = self._svd.transform(tfidf)
        if reduced.shape[1] < self.dim:
            pad = np.zeros((reduced.shape[0], self.dim - reduced.shape[1]))
            reduced = np.hstack([reduced, pad])
        return reduced
