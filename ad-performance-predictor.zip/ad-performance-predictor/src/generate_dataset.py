"""
Generates a synthetic but realistic dataset of Instagram advertisement posts,
including caption text with varying sentiment, post metadata, and engagement metrics.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 12500

brands = ["UrbanThread", "GlowLab", "PeakGear", "BrewCraft", "NovaFit", "PixelHome",
          "TrailMate", "PureLeaf", "CraftKitchen", "AeroSole", "LumaSkin", "ZenDesk"]

categories = ["Fashion", "Beauty", "Fitness", "Food & Beverage", "Home & Living",
              "Tech & Gadgets", "Outdoor & Travel"]

image_types = ["Single Image", "Carousel", "Reel/Video", "Story"]

positive_phrases = [
    "absolutely love this", "game changer", "obsessed with", "best purchase ever",
    "highly recommend", "exceeded my expectations", "so happy with", "worth every penny",
    "can't stop using", "perfect addition to", "life changing", "amazing quality",
    "exactly what I needed", "stunning", "incredible value", "five stars"
]

negative_phrases = [
    "disappointed with", "not worth it", "waste of money", "poor quality",
    "wouldn't recommend", "expected more", "let down by", "overpriced for",
    "broke after", "customer service was terrible", "regret buying",
    "cheaply made", "doesn't work as advertised"
]

neutral_phrases = [
    "check out our new", "introducing the latest", "now available", "shop the",
    "discover our", "just launched", "available now in", "new arrival",
    "limited stock of", "exploring the features of", "here's a look at"
]

hashtag_pool = ["#ad", "#sponsored", "#newlaunch", "#musthave", "#dealoftheday",
                "#trending", "#instagood", "#shopnow", "#discount", "#giveaway",
                "#lifestyle", "#quality", "#handmade", "#sustainable", "#limitededition",
                "#bestseller", "#summer2023", "#weekendvibes", "#selfcare", "#fitlife"]

cta_pool = ["Link in bio!", "Swipe up to shop.", "Tap to learn more.", "Shop now before it's gone.",
            "DM us for details.", "Available at our store.", "", "", ""]

rows = []
for i in range(N):
    brand = np.random.choice(brands)
    category = np.random.choice(categories)
    img_type = np.random.choice(image_types, p=[0.35, 0.30, 0.25, 0.10])

    sentiment_roll = np.random.rand()
    if sentiment_roll < 0.45:
        sentiment_label = "positive"
        phrase = np.random.choice(positive_phrases)
    elif sentiment_roll < 0.65:
        sentiment_label = "negative"
        phrase = np.random.choice(negative_phrases)
    else:
        sentiment_label = "neutral"
        phrase = np.random.choice(neutral_phrases)

    n_hashtags = np.random.randint(0, 12)
    hashtags = " ".join(np.random.choice(hashtag_pool, size=n_hashtags, replace=False)) if n_hashtags else ""
    cta = np.random.choice(cta_pool)

    caption = f"{phrase} the new {brand} collection. {cta} {hashtags}".strip()

    followers = int(np.clip(np.random.lognormal(9.5, 1.3), 500, 2_000_000))
    post_hour = np.random.randint(0, 24)
    day_of_week = np.random.choice(["Mon","Tue","Wed","Thu","Fri","Sat","Sun"])
    is_weekend = day_of_week in ["Sat", "Sun"]
    caption_length = len(caption)

    # --- underlying engagement model (ground truth generative process) ---
    sentiment_score = {"positive": 1.0, "neutral": 0.0, "negative": -0.8}[sentiment_label]
    base_rate = 0.015 + 0.01 * sentiment_score
    base_rate += 0.004 if img_type == "Reel/Video" else (0.002 if img_type == "Carousel" else 0)
    base_rate += 0.003 if is_weekend else 0
    base_rate += 0.0015 if 17 <= post_hour <= 21 else 0
    base_rate += min(n_hashtags, 8) * 0.0008
    base_rate -= max(0, caption_length - 150) * 0.00002
    base_rate += np.random.normal(0, 0.0052)  # noise
    base_rate = max(0.001, base_rate)

    # engagement scales sub-linearly with followers (typical real-world pattern)
    expected_engagements = base_rate * (followers ** 0.9) / (followers ** 0.9 / followers) if followers > 0 else 0
    engagement_rate = base_rate  # fraction of followers engaging
    likes = int(np.random.poisson(max(1, engagement_rate * followers * 0.85)))
    comments = int(np.random.poisson(max(0.5, engagement_rate * followers * 0.08)))
    shares = int(np.random.poisson(max(0.2, engagement_rate * followers * 0.04)))

    total_engagement = likes + comments + shares
    engagement_rate_pct = round((total_engagement / followers) * 100, 4) if followers else 0

    rows.append([
        f"post_{i:05d}", brand, category, caption, img_type, n_hashtags, followers,
        post_hour, day_of_week, is_weekend, caption_length, likes, comments, shares,
        total_engagement, engagement_rate_pct, sentiment_label
    ])

df = pd.DataFrame(rows, columns=[
    "post_id", "brand", "category", "caption", "image_type", "hashtag_count", "followers",
    "post_hour", "day_of_week", "is_weekend", "caption_length", "likes", "comments", "shares",
    "total_engagement", "engagement_rate_pct", "true_sentiment"
])

# Label: High Engagement = top ~45% of engagement_rate_pct within each category (relative, realistic)
df["engagement_class"] = df.groupby("category")["engagement_rate_pct"].transform(
    lambda x: (x >= x.quantile(0.55)).astype(int)
)
df["engagement_label"] = df["engagement_class"].map({1: "High Engagement", 0: "Low Engagement"})

# Inject realistic messiness for the cleaning step
missing_idx = df.sample(frac=0.02, random_state=5).index
df.loc[missing_idx, "caption_length"] = np.nan

dup_rows = df.sample(40, random_state=6)
df = pd.concat([df, dup_rows], ignore_index=True)

df = df.sample(frac=1, random_state=11).reset_index(drop=True)

df.to_csv("data/instagram_posts_raw.csv", index=False)
print(df.shape)
print(df["engagement_label"].value_counts())
print(df.head(3).to_string())
