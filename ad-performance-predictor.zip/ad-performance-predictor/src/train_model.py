"""
Trains an XGBoost classifier to predict whether an Instagram ad post will achieve
"High Engagement" or "Low Engagement", using BERT (or fallback) text embeddings of
the caption plus engineered post metadata features.

Run:
    python src/train_model.py
"""

import os
import sys
import pickle
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix,
                              roc_auc_score, roc_curve)
from sklearn.decomposition import PCA
import xgboost as xgb
import matplotlib.pyplot as plt
import seaborn as sns

sys.path.append(os.path.dirname(__file__))
from embeddings import TextEmbedder
from sentiment import SentimentAnalyzer

sns.set_theme(style="whitegrid", palette="deep")
plt.rcParams["figure.dpi"] = 110

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
IMG_DIR = os.path.join(BASE_DIR, "images")
MODEL_DIR = os.path.join(BASE_DIR, "models")


def clean_data(df):
    df = df.copy()
    df = df.drop_duplicates(subset=["post_id"])
    df["caption_length"] = df["caption_length"].fillna(df["caption"].str.len())
    df["hashtag_count"] = df["hashtag_count"].fillna(0)
    return df.reset_index(drop=True)


def build_features(df, embedder, sentiment_analyzer, fit=True):
    if fit:
        embeddings = embedder.fit_transform(df["caption"])
    else:
        embeddings = embedder.transform(df["caption"])

    sentiment_scores = sentiment_analyzer.score(df["caption"])

    emb_df = pd.DataFrame(embeddings, columns=[f"emb_{i}" for i in range(embeddings.shape[1])])
    emb_df["sentiment_score"] = sentiment_scores

    meta = df[["hashtag_count", "followers", "post_hour", "caption_length"]].reset_index(drop=True)
    meta["is_weekend"] = df["is_weekend"].astype(int).reset_index(drop=True)
    meta["log_followers"] = np.log1p(meta["followers"])

    cat_dummies = pd.get_dummies(df[["category", "image_type", "day_of_week"]].reset_index(drop=True),
                                  drop_first=True)

    features = pd.concat([meta.drop(columns=["followers"]), cat_dummies, emb_df], axis=1)
    return features


def main():
    print("Loading and cleaning data...")
    df = pd.read_csv(os.path.join(DATA_DIR, "instagram_posts_raw.csv"))
    df = clean_data(df)
    print(f"Cleaned dataset: {df.shape}")

    df_train, df_test = train_test_split(df, test_size=0.2, random_state=42,
                                          stratify=df["engagement_class"])

    print("Generating text embeddings...")
    embedder = TextEmbedder()
    print(f"Using {'BERT (sentence-transformers)' if embedder.using_bert else 'TF-IDF + SVD fallback'} embeddings")

    sentiment_analyzer = SentimentAnalyzer()
    print(f"Using {'transformer' if sentiment_analyzer.using_transformer else 'lexicon-based'} sentiment scoring")

    X_train = build_features(df_train, embedder, sentiment_analyzer, fit=True)
    X_test = build_features(df_test, embedder, sentiment_analyzer, fit=False)

    # Align columns (categorical dummies may differ slightly between splits)
    X_train, X_test = X_train.align(X_test, join="left", axis=1, fill_value=0)

    y_train = df_train["engagement_class"].values
    y_test = df_test["engagement_class"].values

    print(f"Training XGBoost on {X_train.shape[1]} features, {X_train.shape[0]} samples...")
    model = xgb.XGBClassifier(
        n_estimators=250,
        max_depth=5,
        learning_rate=0.05,
        subsample=0.85,
        colsample_bytree=0.7,
        reg_lambda=2.0,
        eval_metric="logloss",
        random_state=42,
    )
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    acc = accuracy_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_proba)
    print(f"\nTest Accuracy: {acc:.4f}")
    print(f"Test ROC-AUC: {auc:.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=["Low Engagement", "High Engagement"]))

    os.makedirs(MODEL_DIR, exist_ok=True)
    with open(os.path.join(MODEL_DIR, "xgb_model.pkl"), "wb") as f:
        pickle.dump(model, f)
    with open(os.path.join(MODEL_DIR, "feature_columns.pkl"), "wb") as f:
        pickle.dump(list(X_train.columns), f)
    with open(os.path.join(MODEL_DIR, "embedder.pkl"), "wb") as f:
        pickle.dump(embedder, f)
    with open(os.path.join(MODEL_DIR, "sentiment_analyzer.pkl"), "wb") as f:
        pickle.dump(sentiment_analyzer, f)
    print(f"\nSaved model artifacts to {MODEL_DIR}")

    # --- Visualizations ---
    os.makedirs(IMG_DIR, exist_ok=True)

    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["Low Engagement", "High Engagement"],
                yticklabels=["Low Engagement", "High Engagement"])
    plt.ylabel("Actual")
    plt.xlabel("Predicted")
    plt.title(f"Confusion Matrix (Accuracy: {acc:.1%})")
    plt.tight_layout()
    plt.savefig(os.path.join(IMG_DIR, "confusion_matrix.png"), bbox_inches="tight")
    plt.close()

    # ROC curve
    fpr, tpr, _ = roc_curve(y_test, y_proba)
    plt.figure(figsize=(6.5, 5.5))
    plt.plot(fpr, tpr, linewidth=2, label=f"XGBoost (AUC = {auc:.3f})")
    plt.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Random baseline")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve")
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(IMG_DIR, "roc_curve.png"), bbox_inches="tight")
    plt.close()

    # Feature importance (top 15, grouped: collapse embedding dims into one bucket)
    importances = model.feature_importances_
    feat_names = X_train.columns
    imp_df = pd.DataFrame({"feature": feat_names, "importance": importances})
    imp_df["group"] = imp_df["feature"].apply(lambda x: "text_embedding" if x.startswith("emb_") else x)
    grouped = imp_df.groupby("group")["importance"].sum().sort_values(ascending=False).head(15)

    plt.figure(figsize=(9, 6))
    sns.barplot(x=grouped.values, y=grouped.index, hue=grouped.index, palette="mako", legend=False)
    plt.xlabel("Total Importance")
    plt.title("Top Feature Importance (Grouped)")
    plt.tight_layout()
    plt.savefig(os.path.join(IMG_DIR, "feature_importance.png"), bbox_inches="tight")
    plt.close()

    # Sentiment vs engagement rate
    df_all = pd.concat([df_train, df_test])
    sentiment_scores_all = sentiment_analyzer.score(df_all["caption"])
    df_all = df_all.copy()
    df_all["sentiment_score"] = sentiment_scores_all
    plt.figure(figsize=(8, 5.5))
    sns.boxplot(data=df_all, x="true_sentiment", y="engagement_rate_pct",
                order=["negative", "neutral", "positive"], hue="true_sentiment",
                palette="coolwarm", legend=False)
    plt.title("Engagement Rate by Caption Sentiment")
    plt.ylabel("Engagement Rate (%)")
    plt.xlabel("Sentiment")
    plt.ylim(0, df_all["engagement_rate_pct"].quantile(0.95))
    plt.tight_layout()
    plt.savefig(os.path.join(IMG_DIR, "engagement_by_sentiment.png"), bbox_inches="tight")
    plt.close()

    print(f"Saved 4 charts to {IMG_DIR}")
    print("\nDone.")


if __name__ == "__main__":
    main()
